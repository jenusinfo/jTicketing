namespace TicketingSystem.CLI;
class Program
{
    static void Main(string[] args) { }
}
